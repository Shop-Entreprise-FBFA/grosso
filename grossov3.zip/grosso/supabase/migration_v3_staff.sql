-- =====================================================================
--  GROSSO — MIGRATION v3 : console staff / développeur
-- ---------------------------------------------------------------------
--  À exécuter APRÈS migration_v2_discord.sql. Ré-exécutable sans danger.
--
--  Le staff voit et gère TOUTES les entreprises depuis le site, et
--  n'occupe AUCUNE des 5 places d'une entreprise (il reste non rattaché).
-- =====================================================================

alter table public.profiles add column if not exists is_staff boolean not null default false;

-- ---------------------------------------------------------------------
-- 1. QUI EST STAFF ?
-- ---------------------------------------------------------------------
create or replace function public.is_staff()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select is_staff from public.profiles where id = auth.uid()), false);
$$;
grant execute on function public.is_staff() to authenticated;

-- Nommer un membre du staff. À exécuter DEPUIS LE SQL EDITOR uniquement
-- (volontairement non accessible depuis le site).
-- Exemple :  select public.make_staff('mon_pseudo_discord');
create or replace function public.make_staff(p_identifiant text, p_valeur boolean default true)
returns text language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_nom text;
begin
  select id, coalesce(full_name, discord_username, email) into v_id, v_nom
  from public.profiles
  where lower(discord_username) = lower(trim(p_identifiant))
     or lower(email)            = lower(trim(p_identifiant))
     or id::text                = trim(p_identifiant)
  limit 1;

  if v_id is null then
    return 'Aucun profil trouvé pour « ' || p_identifiant || ' ». Connectez-vous une fois sur le site avec Discord, puis relancez cette commande.';
  end if;

  update public.profiles set is_staff = p_valeur where id = v_id;
  return case when p_valeur then '✅ ' || v_nom || ' est maintenant STAFF.'
              else '⛔ ' || v_nom || ' n''est plus staff.' end;
end $$;
revoke execute on function public.make_staff(text, boolean) from authenticated, anon;

-- ---------------------------------------------------------------------
-- 2. LE STAFF NE CONSOMME PAS DE PLACE
--    (recomptage des membres en excluant le staff)
-- ---------------------------------------------------------------------
create or replace function public.member_count(p_company uuid)
returns integer language sql stable security definer set search_path = public as $$
  select count(*)::int from public.profiles
   where company_id = p_company and is_staff = false;
$$;
grant execute on function public.member_count(uuid) to authenticated;

create or replace function public.join_company(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_company public.companies%rowtype; v_count int; v_current uuid; v_staff boolean;
begin
  if auth.uid() is null then raise exception 'Vous devez être connecté.'; end if;

  select company_id, is_staff into v_current, v_staff from public.profiles where id = auth.uid();
  if v_current is not null then raise exception 'Vous êtes déjà rattaché à une entreprise.'; end if;

  select c.* into v_company
  from public.company_access a
  join public.companies c on c.id = a.company_id
  where upper(replace(a.join_code, ' ', '')) = upper(replace(trim(coalesce(p_code,'')), ' ', ''));

  if not found then raise exception 'Code d''invitation invalide.'; end if;
  if not v_company.is_active then raise exception 'Cette entreprise est désactivée.'; end if;

  v_count := public.member_count(v_company.id);
  if not coalesce(v_staff,false) and v_count >= v_company.max_members then
    raise exception 'Cette entreprise a atteint sa limite de % membres.', v_company.max_members;
  end if;

  update public.profiles
     set company_id = v_company.id,
         role = case when v_count = 0 and not coalesce(v_staff,false) then 'admin' else 'membre' end
   where id = auth.uid();

  return jsonb_build_object('company_id', v_company.id, 'company_name', v_company.name,
                            'role', case when v_count = 0 then 'admin' else 'membre' end);
end $$;
grant execute on function public.join_company(text) to authenticated;

-- ---------------------------------------------------------------------
-- 3. VUE D'ENSEMBLE STAFF
-- ---------------------------------------------------------------------
create or replace function public.staff_overview()
returns jsonb language plpgsql security definer set search_path = public as $$
declare res jsonb;
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;

  select jsonb_build_object(
    'stats', jsonb_build_object(
      'entreprises', (select count(*) from public.companies),
      'actives',     (select count(*) from public.companies where is_active),
      'membres',     (select count(*) from public.profiles where company_id is not null and is_staff = false),
      'articles',    (select count(*) from public.products),
      'commandes',   (select count(*) from public.orders),
      'ca_ht',       (select coalesce(sum(total_ht),0) from public.orders where status <> 'annulee')
    ),
    'companies', coalesce((select jsonb_agg(t.x order by t.x->>'name') from (
        select jsonb_build_object(
          'id', c.id, 'name', c.name, 'city', c.city, 'sector', c.sector, 'country', c.country,
          'siret', c.siret, 'phone', c.phone, 'description', c.description,
          'max_members', c.max_members, 'is_active', c.is_active, 'created_at', c.created_at,
          'join_code', (select join_code from public.company_access a where a.company_id = c.id),
          'members', coalesce((select jsonb_agg(jsonb_build_object(
                'id', p.id, 'name', coalesce(p.full_name, p.discord_username, p.email),
                'discord', p.discord_username, 'role', p.role, 'avatar', p.avatar_url,
                'is_staff', p.is_staff) order by p.created_at)
              from public.profiles p where p.company_id = c.id), '[]'::jsonb),
          'nb_membres',  public.member_count(c.id),
          'nb_articles', (select count(*) from public.products pr where pr.company_id = c.id),
          'nb_ventes',   (select count(*) from public.orders o where o.seller_company_id = c.id),
          'nb_achats',   (select count(*) from public.orders o where o.buyer_company_id = c.id),
          'ca_ht',       (select coalesce(sum(total_ht),0) from public.orders o
                          where o.seller_company_id = c.id and o.status <> 'annulee'),
          'discord_guild_id',   (select discord_guild_id   from public.company_settings s where s.company_id = c.id),
          'discord_channel_id', (select discord_channel_id from public.company_settings s where s.company_id = c.id)
        ) as x from public.companies c) t), '[]'::jsonb),
    'sans_entreprise', coalesce((select jsonb_agg(jsonb_build_object(
          'id', p.id, 'name', coalesce(p.full_name, p.discord_username, p.email),
          'discord', p.discord_username, 'is_staff', p.is_staff, 'created_at', p.created_at)
          order by p.created_at desc)
        from public.profiles p where p.company_id is null), '[]'::jsonb),
    'commandes', coalesce((select jsonb_agg(jsonb_build_object(
          'id', o.id, 'reference', o.reference, 'statut', o.status, 'total_ht', o.total_ht,
          'created_at', o.created_at,
          'acheteur', (select name from public.companies where id = o.buyer_company_id),
          'vendeur',  (select name from public.companies where id = o.seller_company_id))
          order by o.created_at desc)
        from (select * from public.orders order by created_at desc limit 50) o), '[]'::jsonb)
  ) into res;
  return res;
end $$;
grant execute on function public.staff_overview() to authenticated;

-- Détail d'une entreprise (articles + commandes)
create or replace function public.staff_company_detail(p_company uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
declare res jsonb;
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;
  select jsonb_build_object(
    'articles', coalesce((select jsonb_agg(jsonb_build_object(
        'id', p.id, 'name', p.name, 'category', p.category, 'price_ht', p.price_ht,
        'unit', p.unit, 'stock', p.stock, 'is_active', p.is_active) order by p.name)
      from public.products p where p.company_id = p_company), '[]'::jsonb),
    'commandes', coalesce((select jsonb_agg(jsonb_build_object(
        'reference', o.reference, 'statut', o.status, 'total_ht', o.total_ht,
        'sens', case when o.seller_company_id = p_company then 'vente' else 'achat' end,
        'contrepartie', (select name from public.companies where id =
            case when o.seller_company_id = p_company then o.buyer_company_id else o.seller_company_id end),
        'created_at', o.created_at) order by o.created_at desc)
      from public.orders o
      where o.seller_company_id = p_company or o.buyer_company_id = p_company), '[]'::jsonb)
  ) into res;
  return res;
end $$;
grant execute on function public.staff_company_detail(uuid) to authenticated;

-- ---------------------------------------------------------------------
-- 4. ACTIONS STAFF
-- ---------------------------------------------------------------------
create or replace function public.staff_save_company(p_id uuid, p jsonb)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid := p_id; v_code text;
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;
  if coalesce(trim(p->>'name'),'') = '' then raise exception 'Le nom de l''entreprise est obligatoire.'; end if;

  if v_id is null then
    insert into public.companies (name, city, sector, siret, phone, description, country, max_members, is_active)
    values (trim(p->>'name'), nullif(p->>'city',''), nullif(p->>'sector',''), nullif(p->>'siret',''),
            nullif(p->>'phone',''), nullif(p->>'description',''),
            coalesce(nullif(p->>'country',''),'France'),
            greatest(coalesce((p->>'max_members')::int, 5), 1), true)
    returning id into v_id;
  else
    update public.companies set
      name        = coalesce(nullif(trim(p->>'name'),''), name),
      city        = p->>'city',
      sector      = p->>'sector',
      siret       = p->>'siret',
      phone       = p->>'phone',
      description = p->>'description',
      country     = coalesce(nullif(p->>'country',''), country),
      max_members = greatest(coalesce((p->>'max_members')::int, max_members), 1)
    where id = v_id;
  end if;

  insert into public.company_access (company_id, join_code)
  select v_id, public.gen_join_code()
  where not exists (select 1 from public.company_access a where a.company_id = v_id);

  -- réglages Discord facultatifs
  if p ? 'discord_guild_id' or p ? 'discord_channel_id' then
    insert into public.company_settings (company_id, discord_guild_id, discord_channel_id)
    values (v_id, nullif(p->>'discord_guild_id',''), nullif(p->>'discord_channel_id',''))
    on conflict (company_id) do update
      set discord_guild_id = excluded.discord_guild_id,
          discord_channel_id = excluded.discord_channel_id,
          updated_at = now();
  end if;

  select join_code into v_code from public.company_access where company_id = v_id;
  return jsonb_build_object('id', v_id, 'join_code', v_code);
end $$;
grant execute on function public.staff_save_company(uuid, jsonb) to authenticated;

create or replace function public.staff_regenerate_code(p_company uuid)
returns text language plpgsql security definer set search_path = public as $$
declare v_new text;
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;
  v_new := public.gen_join_code();
  update public.company_access set join_code = v_new, created_at = now() where company_id = p_company;
  return v_new;
end $$;
grant execute on function public.staff_regenerate_code(uuid) to authenticated;

create or replace function public.staff_set_active(p_company uuid, p_active boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;
  update public.companies set is_active = p_active where id = p_company;
end $$;
grant execute on function public.staff_set_active(uuid, boolean) to authenticated;

create or replace function public.staff_delete_company(p_company uuid)
returns void language plpgsql security definer set search_path = public as $$
declare n int;
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;
  select count(*) into n from public.orders
   where seller_company_id = p_company or buyer_company_id = p_company;
  if n > 0 then
    raise exception 'Impossible de supprimer : % commande(s) y sont rattachées. Désactivez l''entreprise à la place.', n;
  end if;
  update public.profiles set company_id = null, role = 'membre' where company_id = p_company;
  delete from public.companies where id = p_company;
end $$;
grant execute on function public.staff_delete_company(uuid) to authenticated;

-- Rattacher / détacher / promouvoir n'importe quel membre
create or replace function public.staff_assign_member(p_user uuid, p_company uuid, p_role text default 'membre')
returns void language plpgsql security definer set search_path = public as $$
declare v_max int; v_staff boolean;
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;
  if p_role not in ('admin','membre') then raise exception 'Rôle inconnu.'; end if;

  if p_company is null then
    update public.profiles set company_id = null, role = 'membre' where id = p_user;
    return;
  end if;

  select is_staff into v_staff from public.profiles where id = p_user;
  select max_members into v_max from public.companies where id = p_company;
  if v_max is null then raise exception 'Entreprise introuvable.'; end if;

  if not coalesce(v_staff,false) and public.member_count(p_company) >= v_max then
    raise exception 'Cette entreprise a atteint sa limite de % membres.', v_max;
  end if;

  update public.profiles set company_id = p_company, role = p_role where id = p_user;
end $$;
grant execute on function public.staff_assign_member(uuid, uuid, text) to authenticated;

create or replace function public.staff_set_staff(p_user uuid, p_valeur boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_staff() then raise exception 'Accès réservé au staff.'; end if;
  if p_user = auth.uid() and p_valeur = false then
    raise exception 'Vous ne pouvez pas retirer votre propre accès staff.';
  end if;
  update public.profiles set is_staff = p_valeur where id = p_user;
end $$;
grant execute on function public.staff_set_staff(uuid, boolean) to authenticated;

-- ---------------------------------------------------------------------
-- 5. NOMMEZ-VOUS STAFF
-- ---------------------------------------------------------------------
-- Connectez-vous UNE FOIS sur le site avec Discord, puis exécutez la ligne
-- ci-dessous en remplaçant la valeur par votre pseudo Discord ou votre e-mail :
--
--    select public.make_staff('votre_pseudo_discord');
--
-- Pour retirer l'accès staff à quelqu'un :
--    select public.make_staff('un_pseudo', false);

select 'Migration v3 appliquée. Exécutez maintenant :  select public.make_staff(''votre_pseudo_discord'');' as etape_suivante;
