-- =====================================================================
--  GROSSO — MIGRATION v2 : connexion Discord, équipes, codes d'invitation
-- ---------------------------------------------------------------------
--  À exécuter dans Supabase → SQL Editor, APRÈS schema.sql (v1).
--  Ré-exécutable sans danger. Ne détruit aucune donnée existante.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. NOUVELLES COLONNES
-- ---------------------------------------------------------------------
alter table public.companies add column if not exists max_members integer not null default 5;
alter table public.companies add column if not exists is_active   boolean not null default true;

alter table public.profiles  add column if not exists discord_id       text;
alter table public.profiles  add column if not exists discord_username text;
alter table public.profiles  add column if not exists avatar_url       text;
alter table public.profiles  alter column role set default 'membre';

-- ---------------------------------------------------------------------
-- 2. CODES D'INVITATION (table à part : le code ne doit pas être
--    lisible par les autres entreprises)
-- ---------------------------------------------------------------------
create table if not exists public.company_access (
  company_id uuid primary key references public.companies(id) on delete cascade,
  join_code  text not null unique,
  created_at timestamptz not null default now()
);

-- Génère un code lisible du type ABCD-2345 (sans 0/O/1/I pour éviter les confusions)
create or replace function public.gen_join_code()
returns text language plpgsql as $$
declare
  alphabet text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  res text := '';
  i int;
begin
  for i in 1..8 loop
    res := res || substr(alphabet, 1 + floor(random() * length(alphabet))::int, 1);
    if i = 4 then res := res || '-'; end if;
  end loop;
  return res;
end $$;

-- Toute entreprise sans code en reçoit un
insert into public.company_access (company_id, join_code)
select c.id, public.gen_join_code()
from public.companies c
where not exists (select 1 from public.company_access a where a.company_id = c.id);

-- ---------------------------------------------------------------------
-- 3. RÉGLAGES DISCORD PAR ENTREPRISE (privés)
-- ---------------------------------------------------------------------
create table if not exists public.company_settings (
  company_id         uuid primary key references public.companies(id) on delete cascade,
  discord_guild_id   text,   -- identifiant du serveur Discord de l'entreprise
  discord_channel_id text,   -- salon où le bot annoncera les commandes
  discord_webhook_url text,  -- optionnel, si vous préférez un webhook au bot
  updated_at         timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 4. FILE D'ÉVÉNEMENTS POUR LE FUTUR BOT
--    Le bot lira cette table avec la clé service_role, postera sur Discord,
--    puis passera delivered = true.
-- ---------------------------------------------------------------------
create table if not exists public.notifications (
  id           bigserial primary key,
  company_id   uuid not null references public.companies(id) on delete cascade,
  kind         text not null,          -- nouvelle_commande | changement_statut
  order_id     uuid references public.orders(id) on delete cascade,
  payload      jsonb not null,
  delivered    boolean not null default false,
  delivered_at timestamptz,
  created_at   timestamptz not null default now()
);
create index if not exists idx_notif_pending on public.notifications(delivered, created_at);

-- ---------------------------------------------------------------------
-- 5. FONCTIONS UTILITAIRES
-- ---------------------------------------------------------------------
create or replace function public.my_company_id()
returns uuid language sql stable security definer set search_path = public as $$
  select company_id from public.profiles where id = auth.uid();
$$;

create or replace function public.my_role()
returns text language sql stable security definer set search_path = public as $$
  select role from public.profiles where id = auth.uid();
$$;

create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role from public.profiles where id = auth.uid()) = 'admin', false);
$$;

-- ---------------------------------------------------------------------
-- 6. INSCRIPTION — plus de création d'entreprise !
--    On crée seulement le profil, sans entreprise. Le membre rejoindra
--    ensuite son entreprise avec le code d'invitation.
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
begin
  insert into public.profiles (id, email, full_name, discord_username, discord_id, avatar_url, company_id, role)
  values (
    new.id,
    new.email,
    coalesce(nullif(m->>'full_name',''), nullif(m->>'global_name',''), nullif(m->>'name',''), nullif(m->>'user_name','')),
    coalesce(nullif(m->>'user_name',''), nullif(m->>'name','')),
    coalesce(nullif(m->>'provider_id',''), nullif(m->>'sub','')),
    nullif(m->>'avatar_url',''),
    null,
    'membre'
  )
  on conflict (id) do update
    set avatar_url       = coalesce(excluded.avatar_url, public.profiles.avatar_url),
        discord_username = coalesce(excluded.discord_username, public.profiles.discord_username),
        discord_id       = coalesce(excluded.discord_id, public.profiles.discord_id);
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- 7. REJOINDRE UNE ENTREPRISE AVEC UN CODE
-- ---------------------------------------------------------------------
create or replace function public.join_company(p_code text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare
  v_company public.companies%rowtype;
  v_count   integer;
  v_current uuid;
begin
  if auth.uid() is null then raise exception 'Vous devez être connecté.'; end if;

  select company_id into v_current from public.profiles where id = auth.uid();
  if v_current is not null then
    raise exception 'Vous êtes déjà rattaché à une entreprise.';
  end if;

  select c.* into v_company
  from public.company_access a
  join public.companies c on c.id = a.company_id
  where upper(replace(a.join_code, ' ', '')) = upper(replace(trim(coalesce(p_code,'')), ' ', ''));

  if not found then raise exception 'Code d''invitation invalide.'; end if;
  if not v_company.is_active then raise exception 'Cette entreprise est désactivée.'; end if;

  select count(*) into v_count from public.profiles where company_id = v_company.id;
  if v_count >= v_company.max_members then
    raise exception 'Cette entreprise a atteint sa limite de % membres.', v_company.max_members;
  end if;

  update public.profiles
     set company_id = v_company.id,
         role = case when v_count = 0 then 'admin' else 'membre' end
   where id = auth.uid();

  return jsonb_build_object(
    'company_id', v_company.id,
    'company_name', v_company.name,
    'role', case when v_count = 0 then 'admin' else 'membre' end
  );
end $$;

-- Régénérer le code (admin seulement)
create or replace function public.regenerate_join_code()
returns text language plpgsql security definer set search_path = public as $$
declare v_new text;
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur de l''entreprise.'; end if;
  v_new := public.gen_join_code();
  update public.company_access set join_code = v_new, created_at = now()
   where company_id = public.my_company_id();
  return v_new;
end $$;

-- Retirer un membre (admin seulement, pas soi-même)
create or replace function public.remove_member(p_user uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur de l''entreprise.'; end if;
  if p_user = auth.uid() then raise exception 'Vous ne pouvez pas vous retirer vous-même.'; end if;
  update public.profiles set company_id = null, role = 'membre'
   where id = p_user and company_id = public.my_company_id();
end $$;

-- Changer le rôle d'un membre (admin seulement)
create or replace function public.set_member_role(p_user uuid, p_role text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Réservé à l''administrateur de l''entreprise.'; end if;
  if p_role not in ('admin','membre') then raise exception 'Rôle inconnu.'; end if;
  if p_user = auth.uid() and p_role = 'membre'
     and (select count(*) from public.profiles where company_id = public.my_company_id() and role = 'admin') <= 1 then
    raise exception 'Il doit rester au moins un administrateur.';
  end if;
  update public.profiles set role = p_role
   where id = p_user and company_id = public.my_company_id();
end $$;

-- ---------------------------------------------------------------------
-- 8. COMMANDE + ÉVÉNEMENT POUR LE BOT
-- ---------------------------------------------------------------------
create or replace function public.place_order(p_seller uuid, p_items jsonb, p_note text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_buyer uuid := public.my_company_id();
  v_order uuid;
  v_total numeric(12,2) := 0;
  v_ref   text;
  it   jsonb;
  prod public.products%rowtype;
  qty  integer;
  line numeric(12,2);
  v_lines jsonb := '[]'::jsonb;
begin
  if v_buyer is null then raise exception 'Aucune entreprise rattachée à ce compte.'; end if;
  if p_seller = v_buyer then raise exception 'Impossible de commander auprès de sa propre entreprise.'; end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then raise exception 'Le panier est vide.'; end if;

  insert into public.orders (buyer_company_id, seller_company_id, note)
  values (v_buyer, p_seller, p_note)
  returning id, reference into v_order, v_ref;

  for it in select * from jsonb_array_elements(p_items) loop
    select * into prod from public.products
      where id = (it->>'product_id')::uuid and company_id = p_seller and is_active;
    if not found then raise exception 'Article introuvable ou indisponible.'; end if;

    qty  := greatest(coalesce((it->>'quantity')::int, 1), prod.min_qty);
    line := round(prod.price_ht * qty, 2);
    v_total := v_total + line;

    insert into public.order_items (order_id, product_id, product_name, unit, unit_price_ht, quantity, line_total)
    values (v_order, prod.id, prod.name, prod.unit, prod.price_ht, qty, line);

    update public.products set stock = greatest(stock - qty, 0) where id = prod.id;

    v_lines := v_lines || jsonb_build_object('article', prod.name, 'quantite', qty, 'unite', prod.unit, 'total_ht', line);
  end loop;

  update public.orders set total_ht = v_total where id = v_order;

  -- événement à destination du futur bot Discord (côté vendeur)
  insert into public.notifications (company_id, kind, order_id, payload)
  values (p_seller, 'nouvelle_commande', v_order, jsonb_build_object(
    'reference',   v_ref,
    'acheteur',    (select name from public.companies where id = v_buyer),
    'vendeur',     (select name from public.companies where id = p_seller),
    'total_ht',    v_total,
    'devise',      'EUR',
    'note',        p_note,
    'lignes',      v_lines,
    'discord_guild_id',   (select discord_guild_id   from public.company_settings where company_id = p_seller),
    'discord_channel_id', (select discord_channel_id from public.company_settings where company_id = p_seller),
    'discord_webhook_url',(select discord_webhook_url from public.company_settings where company_id = p_seller)
  ));

  return v_order;
end $$;

-- Événement quand le statut change : on prévient l'autre partie
create or replace function public.notify_status_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_target uuid;
begin
  if new.status is not distinct from old.status then return new; end if;

  v_target := case when public.my_company_id() = new.seller_company_id
                   then new.buyer_company_id else new.seller_company_id end;

  insert into public.notifications (company_id, kind, order_id, payload)
  values (v_target, 'changement_statut', new.id, jsonb_build_object(
    'reference',  new.reference,
    'statut',     new.status,
    'ancien_statut', old.status,
    'total_ht',   new.total_ht,
    'acheteur',   (select name from public.companies where id = new.buyer_company_id),
    'vendeur',    (select name from public.companies where id = new.seller_company_id),
    'discord_guild_id',   (select discord_guild_id   from public.company_settings where company_id = v_target),
    'discord_channel_id', (select discord_channel_id from public.company_settings where company_id = v_target),
    'discord_webhook_url',(select discord_webhook_url from public.company_settings where company_id = v_target)
  ));
  return new;
end $$;

drop trigger if exists on_order_status_change on public.orders;
create trigger on_order_status_change
  after update on public.orders
  for each row execute function public.notify_status_change();

-- ---------------------------------------------------------------------
-- 9. SÉCURITÉ (RLS) — un compte sans entreprise ne voit rien du marché
-- ---------------------------------------------------------------------
alter table public.company_access   enable row level security;
alter table public.company_settings enable row level security;
alter table public.notifications    enable row level security;

-- annuaire des entreprises : réservé aux membres rattachés
drop policy if exists companies_select on public.companies;
create policy companies_select on public.companies
  for select to authenticated using (public.my_company_id() is not null);

-- modification de la fiche entreprise : admin seulement
drop policy if exists companies_update on public.companies;
create policy companies_update on public.companies
  for update to authenticated
  using (id = public.my_company_id() and public.is_admin())
  with check (id = public.my_company_id() and public.is_admin());

-- catalogue : réservé aux membres rattachés
drop policy if exists products_select on public.products;
create policy products_select on public.products
  for select to authenticated
  using ((is_active and public.my_company_id() is not null)
      or company_id = public.my_company_id());

-- code d'invitation : visible seulement par les membres de l'entreprise
drop policy if exists company_access_select on public.company_access;
create policy company_access_select on public.company_access
  for select to authenticated using (company_id = public.my_company_id());

-- réglages Discord : lecture par les membres, écriture par l'admin
drop policy if exists company_settings_select on public.company_settings;
create policy company_settings_select on public.company_settings
  for select to authenticated using (company_id = public.my_company_id());

drop policy if exists company_settings_insert on public.company_settings;
create policy company_settings_insert on public.company_settings
  for insert to authenticated
  with check (company_id = public.my_company_id() and public.is_admin());

drop policy if exists company_settings_update on public.company_settings;
create policy company_settings_update on public.company_settings
  for update to authenticated
  using (company_id = public.my_company_id() and public.is_admin())
  with check (company_id = public.my_company_id() and public.is_admin());

-- notifications : lecture par l'entreprise concernée (le bot, lui, utilise service_role)
drop policy if exists notifications_select on public.notifications;
create policy notifications_select on public.notifications
  for select to authenticated using (company_id = public.my_company_id());

-- ---------------------------------------------------------------------
-- 10. DROITS
-- ---------------------------------------------------------------------
grant select, insert, update, delete on
  public.company_access, public.company_settings, public.notifications to authenticated;
grant usage, select on all sequences in schema public to authenticated;
grant execute on function public.join_company(text)            to authenticated;
grant execute on function public.regenerate_join_code()        to authenticated;
grant execute on function public.remove_member(uuid)           to authenticated;
grant execute on function public.set_member_role(uuid, text)   to authenticated;
grant execute on function public.my_role()                     to authenticated;
grant execute on function public.is_admin()                    to authenticated;

-- ---------------------------------------------------------------------
-- 11. RATTRAPAGE — les membres déjà présents deviennent admin de leur
--     entreprise s'il n'y a pas encore d'administrateur.
-- ---------------------------------------------------------------------
update public.profiles p set role = 'admin'
where p.company_id is not null
  and not exists (select 1 from public.profiles q
                  where q.company_id = p.company_id and q.role = 'admin');

-- ---------------------------------------------------------------------
--  VOS CODES D'INVITATION — le résultat s'affiche après exécution
-- ---------------------------------------------------------------------
select c.name as entreprise,
       a.join_code as code_invitation,
       (select count(*) from public.profiles p where p.company_id = c.id) || ' / ' || c.max_members as membres
from public.companies c
join public.company_access a on a.company_id = c.id
order by c.name;
