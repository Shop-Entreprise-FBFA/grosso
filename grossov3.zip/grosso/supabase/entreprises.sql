-- =====================================================================
--  GROSSO — Pré-remplir vos entreprises
-- ---------------------------------------------------------------------
--  À exécuter dans Supabase → SQL Editor, APRÈS migration_v2_discord.sql.
--  Modifiez la liste ci-dessous, puis exécutez. Ré-exécutable :
--  une entreprise déjà présente (même nom) est mise à jour, pas dupliquée.
--
--  Chaque entreprise reçoit automatiquement son code d'invitation,
--  affiché à la fin. Transmettez ce code aux 5 personnes concernées.
-- =====================================================================

-- ⬇️ MODIFIEZ UNIQUEMENT CE BLOC ⬇️
-- Colonnes : nom, ville, secteur, nb max de membres, présentation
with saisie(name, city, sector, max_members, description) as (values
  ('Oil Roxwood',        'Lille',     'Carburants',   5, 'Distribution de carburants et lubrifiants.'),
  ('Distribution Martin','Lyon',      'Alimentaire',  5, 'Épicerie sèche et boissons pour la restauration.'),
  ('Beta Import',        'Marseille', 'Épicerie',     5, 'Importation de produits secs.'),
  ('Gamma Frais',        'Rungis',    'Fruits & légumes', 5, 'Produits frais, livraison quotidienne.')
  -- ajoutez vos lignes ici, séparées par une virgule
)
-- ⬆️ NE RIEN MODIFIER EN DESSOUS ⬆️
, upsert as (
  insert into public.companies (name, city, sector, max_members, description, country, is_active)
  select s.name, s.city, s.sector, s.max_members, s.description, 'France', true
  from saisie s
  where not exists (select 1 from public.companies c where lower(c.name) = lower(s.name))
  returning id, name
)
select 'Créée : ' || name as resultat from upsert;

-- Mise à jour des entreprises déjà existantes (nom identique)
update public.companies c
   set city = s.city, sector = s.sector, max_members = s.max_members, description = s.description
from (values
  ('Oil Roxwood',        'Lille',     'Carburants',   5, 'Distribution de carburants et lubrifiants.'),
  ('Distribution Martin','Lyon',      'Alimentaire',  5, 'Épicerie sèche et boissons pour la restauration.'),
  ('Beta Import',        'Marseille', 'Épicerie',     5, 'Importation de produits secs.'),
  ('Gamma Frais',        'Rungis',    'Fruits & légumes', 5, 'Produits frais, livraison quotidienne.')
) as s(name, city, sector, max_members, description)
where lower(c.name) = lower(s.name);

-- Attribution d'un code d'invitation aux entreprises qui n'en ont pas
insert into public.company_access (company_id, join_code)
select c.id, public.gen_join_code()
from public.companies c
where not exists (select 1 from public.company_access a where a.company_id = c.id);

-- ---------------------------------------------------------------------
--  RÉSULTAT : la liste à distribuer
-- ---------------------------------------------------------------------
select c.name        as entreprise,
       c.city        as ville,
       a.join_code   as code_a_transmettre,
       (select count(*) from public.profiles p where p.company_id = c.id)
         || ' / ' || c.max_members as membres
from public.companies c
join public.company_access a on a.company_id = c.id
order by c.name;
