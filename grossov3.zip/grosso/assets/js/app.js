/* =====================================================================
   Grosso — application (espace entreprise)
   ===================================================================== */
import { sb, configOK, $, $$, money, dateFR, esc, toast, humanError, showSetupScreen } from "./common.js";

if (!configOK) { showSetupScreen(); throw new Error("config"); }

const STATUS = {
  en_attente: { label: "En attente", cls: "badge-warn" },
  confirmee:  { label: "Confirmée",  cls: "badge-info" },
  expediee:   { label: "Expédiée",   cls: "badge-info" },
  livree:     { label: "Livrée",     cls: "badge-ok" },
  annulee:    { label: "Annulée",    cls: "badge-danger" },
};
const UNITS = ["unité", "carton", "palette", "kg", "litre", "lot"];

const state = { user: null, profile: null, company: null, cart: [] };
const isAdmin = () => state.profile?.role === "admin";

/* ---------------------------------------------------------------- boot */
(async function boot() {
  const { data: { session } } = await sb.auth.getSession();
  if (!session) { location.replace("index.html"); return; }
  state.user = session.user;

  const { data: profile, error } = await sb
    .from("profiles").select("*, companies(*)").eq("id", state.user.id).single();

  if (error || !profile) {
    fatal("Profil introuvable",
      `Votre compte Discord est reconnu mais aucun profil n'a été créé en base.
       Vérifiez que le script <code>migration_v2_discord.sql</code> a bien été exécuté dans Supabase.`);
    return;
  }
  state.profile = profile;
  state.company = profile.companies;

  // Pas rattaché à une entreprise : staff → console, sinon écran de code
  if (!profile.company_id && !profile.is_staff) { joinScreen(); return; }

  loadCart();
  $("#brandName").textContent = window.CONFIG.APP_NAME || "Grosso";

  if (profile.is_staff) $("#navStaff").hidden = false;

  // Staff non rattaché : on ne montre que la console
  if (!profile.company_id) {
    $$("#nav a").forEach(a => { if (a.dataset.view !== "staff") a.hidden = true; });
    $("#whoCompany").textContent = "Console staff";
    if (!location.hash) location.hash = "#staff";
  } else {
    $("#whoCompany").textContent = state.company?.name || "Entreprise";
  }
  $("#whoEmail").textContent = displayName(profile)
    + (profile.is_staff ? " · staff" : isAdmin() ? " · admin" : "");
  if (profile.avatar_url) { const a = $("#whoAvatar"); a.src = profile.avatar_url; a.hidden = false; }
  $("#logout").onclick = logout;
  $("#modalClose").onclick = closeModal;
  $("#modalBg").onclick = (e) => { if (e.target.id === "modalBg") closeModal(); };

  $("#boot").hidden = true;
  $("#app").hidden = false;

  window.addEventListener("hashchange", route);
  refreshCartBadge();
  route();
})();

const displayName = (p) =>
  p.full_name || p.discord_username || p.email || "Membre";

async function logout() { await sb.auth.signOut(); location.replace("index.html"); }

function fatal(title, html) {
  document.body.innerHTML =
    `<div class="center-screen"><div class="setup card card-pad">
       <h1>${esc(title)}</h1><p>${html}</p>
       <button class="btn btn-primary" id="fb">Retour à l'accueil</button></div></div>`;
  $("#fb").onclick = () => location.replace("index.html");
}

/* =============================== ÉCRAN « REJOINDRE UNE ENTREPRISE » === */
function joinScreen() {
  const p = state.profile;
  $("#boot").hidden = true;
  document.body.innerHTML = `
    <div class="center-screen">
      <div class="card card-pad" style="max-width:440px;width:100%">
        <div class="member" style="margin-bottom:1.4rem">
          ${p.avatar_url ? `<img class="avatar" src="${esc(p.avatar_url)}" alt="">` : ""}
          <div class="meta"><b>${esc(displayName(p))}</b>
            <span class="hint">Connecté avec Discord</span></div>
        </div>
        <h1 style="font-size:1.4rem">Rejoindre votre entreprise</h1>
        <p class="hint">Saisissez le code d'invitation qui vous a été transmis. Une seule fois : ensuite vous arriverez directement dans votre espace.</p>
        <form id="jf" style="margin-top:1.2rem">
          <div class="field">
            <label for="jc">Code d'invitation</label>
            <input id="jc" class="join-code" required maxlength="9" placeholder="ABCD-2345" autocomplete="off">
          </div>
          <button class="btn btn-primary btn-block" type="submit">Rejoindre</button>
        </form>
        <p id="jmsg" class="hint" style="margin-top:.9rem"></p>
        <hr style="border:0;border-top:1px solid var(--border);margin:1.4rem 0">
        <p class="hint">Vous n'avez pas de code ? Demandez-le à la personne qui gère l'espace de votre entreprise.</p>
        <button class="btn btn-ghost btn-sm" id="jout">Se déconnecter</button>
      </div>
    </div>
    <div id="toasts"></div>`;

  $("#jout").onclick = logout;
  const input = $("#jc");
  input.oninput = () => {
    let v = input.value.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 8);
    input.value = v.length > 4 ? v.slice(0, 4) + "-" + v.slice(4) : v;
  };
  $("#jf").onsubmit = async (e) => {
    e.preventDefault();
    const b = e.target.querySelector("button");
    b.disabled = true; b.textContent = "Vérification…";
    const { data, error } = await sb.rpc("join_company", { p_code: input.value });
    if (error) {
      b.disabled = false; b.textContent = "Rejoindre";
      $("#jmsg").textContent = humanError(error);
      toast(humanError(error), "err");
      return;
    }
    toast(`Bienvenue chez ${data.company_name}`, "ok");
    location.reload();
  };
}

/* --------------------------------------------------------------- panier */
const cartKey = () => "grosso_cart_" + state.user.id;
function loadCart() { try { state.cart = JSON.parse(localStorage.getItem(cartKey())) || []; } catch { state.cart = []; } }
function saveCart() { localStorage.setItem(cartKey(), JSON.stringify(state.cart)); refreshCartBadge(); }
function refreshCartBadge() {
  const n = state.cart.reduce((s, i) => s + i.qty, 0);
  const b = $("#cartCount"); if (!b) return;
  b.textContent = n; b.hidden = n === 0;
}
function addToCart(p, qty) {
  const line = state.cart.find((i) => i.product_id === p.id);
  if (line) line.qty += qty;
  else state.cart.push({
    product_id: p.id, name: p.name, price: Number(p.price_ht), unit: p.unit,
    min_qty: p.min_qty, seller_id: p.company_id, seller_name: p.company_name, qty,
  });
  saveCart();
  toast(`${p.name} ajouté au panier`, "ok");
}

/* -------------------------------------------------------------- modale */
function openModal(title, html) {
  $("#modalTitle").textContent = title;
  $("#modalContent").innerHTML = html;
  $("#modalBg").classList.add("open");
}
function closeModal() { $("#modalBg").classList.remove("open"); }

/* -------------------------------------------------------------- router */
const VIEWS = {
  accueil: viewHome,
  catalogue: viewCatalog,
  "mes-articles": viewMyProducts,
  panier: viewCart,
  achats: viewPurchases,
  ventes: viewSales,
  equipe: viewTeam,
  entreprise: viewCompany,
  staff: viewStaff,
};

async function route() {
  const name = (location.hash.replace("#", "") || (state.company ? "accueil" : "staff"));
  // Un staff non rattaché n'a accès qu'à la console
  const allowed = state.company ? name : "staff";
  const fn = VIEWS[allowed] || (state.company ? viewHome : viewStaff);
  $$("#nav a").forEach((a) => a.classList.toggle("active", a.dataset.view === allowed));
  $("#view").innerHTML = `<p class="hint">Chargement…</p>`;
  try { await fn(); }
  catch (e) { $("#view").innerHTML = `<div class="empty"><div class="big">⚠️</div><p>${esc(humanError(e))}</p></div>`; }
}

const head = (title, sub, actions = "") =>
  `<div class="page-head"><div><h1>${esc(title)}</h1><p>${esc(sub)}</p></div><div>${actions}</div></div>`;

const empty = (icon, text, sub = "") =>
  `<div class="empty card card-pad"><div class="big">${icon}</div><p><b>${esc(text)}</b></p><p class="hint">${esc(sub)}</p></div>`;

/* ============================================================ ACCUEIL */
async function viewHome() {
  const cid = state.company.id;
  const [prods, asSeller, asBuyer, companies, team] = await Promise.all([
    sb.from("products").select("id,is_active,stock").eq("company_id", cid),
    sb.from("orders").select("*").eq("seller_company_id", cid).order("created_at", { ascending: false }),
    sb.from("orders").select("*").eq("buyer_company_id", cid).order("created_at", { ascending: false }),
    sb.from("companies").select("id", { count: "exact", head: true }),
    sb.from("profiles").select("id", { count: "exact", head: true }).eq("company_id", cid),
  ]);

  const P = prods.data || [], S = asSeller.data || [], B = asBuyer.data || [];
  const ca = S.filter((o) => o.status !== "annulee").reduce((s, o) => s + Number(o.total_ht), 0);
  const achats = B.filter((o) => o.status !== "annulee").reduce((s, o) => s + Number(o.total_ht), 0);
  const attente = S.filter((o) => o.status === "en_attente").length;

  const recent = [...S.map(o => ({ ...o, sens: "vente" })), ...B.map(o => ({ ...o, sens: "achat" }))]
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at)).slice(0, 6);
  const names = await companyNames([...new Set(recent.flatMap(o => [o.buyer_company_id, o.seller_company_id]))]);

  $("#view").innerHTML =
    head(`Bonjour, ${state.company.name}`, "Vue d'ensemble de votre activité sur la place de marché") + `
    <div class="grid stats">
      <div class="stat"><div class="label">Mes articles</div><div class="value">${P.length}</div>
        <div class="sub">${P.filter(p => p.is_active).length} en ligne</div></div>
      <div class="stat"><div class="label">Commandes reçues</div><div class="value">${S.length}</div>
        <div class="sub">${attente} en attente de traitement</div></div>
      <div class="stat"><div class="label">Chiffre d'affaires HT</div><div class="value">${money(ca)}</div>
        <div class="sub">toutes commandes reçues</div></div>
      <div class="stat"><div class="label">Mes achats HT</div><div class="value">${money(achats)}</div>
        <div class="sub">${B.length} commande(s) passée(s)</div></div>
    </div>

    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(280px,1fr))">
      <div class="card card-pad">
        <h3>Démarrer</h3>
        <p class="hint">Votre équipe : ${team.count ?? "—"} / ${state.company.max_members ?? 5} membres.</p>
        <div style="display:flex;flex-direction:column;gap:.5rem">
          <a class="btn btn-primary" href="#mes-articles">Publier un article</a>
          <a class="btn btn-ghost" href="#catalogue">Parcourir le catalogue (${companies.count ?? "…"} entreprises)</a>
          <a class="btn btn-ghost" href="#equipe">Inviter un collègue</a>
        </div>
      </div>
      <div class="card" style="grid-column:span 2;min-width:0">
        <div class="card-pad" style="padding-bottom:.4rem"><h3>Dernière activité</h3></div>
        ${recent.length ? `<table><thead><tr><th>Réf.</th><th>Type</th><th>Contrepartie</th><th>Statut</th><th class="num">Montant HT</th><th class="num">Date</th></tr></thead><tbody>
          ${recent.map(o => `<tr>
            <td><b>${esc(o.reference)}</b></td>
            <td>${o.sens === "vente" ? "📤 Vente" : "📥 Achat"}</td>
            <td>${esc(names[o.sens === "vente" ? o.buyer_company_id : o.seller_company_id] || "—")}</td>
            <td><span class="badge ${STATUS[o.status]?.cls || ""}">${STATUS[o.status]?.label || o.status}</span></td>
            <td class="num">${money(o.total_ht)}</td>
            <td class="num hint">${dateFR(o.created_at)}</td></tr>`).join("")}
        </tbody></table>` : `<div class="card-pad"><p class="hint">Aucune commande pour le moment.</p></div>`}
      </div>
    </div>`;
}

async function companyNames(ids) {
  const clean = ids.filter(Boolean);
  if (!clean.length) return {};
  const { data } = await sb.from("companies").select("id,name").in("id", clean);
  return Object.fromEntries((data || []).map((c) => [c.id, c.name]));
}

/* ========================================================== CATALOGUE */
let catalogCache = null;
async function viewCatalog() {
  const { data, error } = await sb.from("catalog").select("*")
    .eq("is_active", true).neq("company_id", state.company.id)
    .order("created_at", { ascending: false });
  if (error) throw error;
  catalogCache = data || [];

  const cats = [...new Set(catalogCache.map((p) => p.category).filter(Boolean))].sort();
  const cos  = [...new Map(catalogCache.map((p) => [p.company_id, p.company_name])).entries()]
                 .sort((a, b) => a[1].localeCompare(b[1]));

  $("#view").innerHTML =
    head("Catalogue général", `${catalogCache.length} article(s) proposé(s) par ${cos.length} entreprise(s)`) + `
    <div class="toolbar">
      <input id="fSearch" type="search" placeholder="Rechercher un article, une référence…">
      <select id="fCat"><option value="">Toutes les catégories</option>${cats.map(c => `<option>${esc(c)}</option>`).join("")}</select>
      <select id="fCo"><option value="">Toutes les entreprises</option>${cos.map(([id, n]) => `<option value="${id}">${esc(n)}</option>`).join("")}</select>
      <select id="fSort"><option value="recent">Plus récents</option><option value="price">Prix croissant</option><option value="name">Nom A→Z</option></select>
    </div>
    <div id="catalogGrid" class="grid grid-products"></div>`;

  const render = () => {
    const q  = $("#fSearch").value.trim().toLowerCase();
    const c  = $("#fCat").value, co = $("#fCo").value, s = $("#fSort").value;
    let list = catalogCache.filter((p) =>
      (!c || p.category === c) && (!co || p.company_id === co) &&
      (!q || [p.name, p.sku, p.description, p.company_name].join(" ").toLowerCase().includes(q)));
    if (s === "price") list.sort((a, b) => a.price_ht - b.price_ht);
    if (s === "name")  list.sort((a, b) => a.name.localeCompare(b.name));

    $("#catalogGrid").innerHTML = list.length
      ? list.map(productCard).join("")
      : empty("🔍", "Aucun article ne correspond", "Essayez d'élargir votre recherche.");

    $$("#catalogGrid .add").forEach((btn) => {
      btn.onclick = () => {
        const p = catalogCache.find((x) => x.id === btn.dataset.id);
        const input = btn.parentElement.querySelector("input");
        addToCart(p, Math.max(parseInt(input.value, 10) || p.min_qty, p.min_qty));
      };
    });
  };
  ["fSearch", "fCat", "fCo", "fSort"].forEach((id) => { $("#" + id).oninput = render; });
  render();
}

const productCard = (p) => `
  <article class="card product">
    <div class="thumb">${p.image_url ? `<img src="${esc(p.image_url)}" alt="" loading="lazy">` : "📦"}</div>
    <div class="body">
      <div class="seller">${esc(p.company_name)}${p.company_city ? " · " + esc(p.company_city) : ""}</div>
      <div class="name">${esc(p.name)}</div>
      <div class="hint">${p.category ? esc(p.category) + " · " : ""}${p.stock > 0 ? p.stock + " en stock" : "stock à confirmer"}</div>
      <div class="price">${money(p.price_ht)} <small>HT / ${esc(p.unit)}</small></div>
      <div class="hint">Minimum : ${p.min_qty} ${esc(p.unit)}</div>
      <div class="actions">
        <input class="qty" type="number" min="${p.min_qty}" step="1" value="${p.min_qty}" aria-label="Quantité">
        <button class="btn btn-primary btn-sm add" data-id="${p.id}" style="flex:1">Ajouter</button>
      </div>
    </div>
  </article>`;

/* ======================================================= MES ARTICLES */
async function viewMyProducts() {
  const { data, error } = await sb.from("products").select("*")
    .eq("company_id", state.company.id).order("created_at", { ascending: false });
  if (error) throw error;

  $("#view").innerHTML =
    head("Mes articles", "Ce que votre entreprise propose aux autres membres",
         `<button class="btn btn-primary" id="btnNew">+ Nouvel article</button>`) +
    (data.length ? `<div class="card"><table>
      <thead><tr><th>Article</th><th>Catégorie</th><th class="num">Prix HT</th><th class="num">Min.</th><th class="num">Stock</th><th>État</th><th></th></tr></thead>
      <tbody>${data.map(p => `<tr>
        <td><b>${esc(p.name)}</b>${p.sku ? `<div class="hint">${esc(p.sku)}</div>` : ""}</td>
        <td>${esc(p.category || "—")}</td>
        <td class="num">${money(p.price_ht)}<div class="hint">/ ${esc(p.unit)}</div></td>
        <td class="num">${p.min_qty}</td>
        <td class="num">${p.stock}</td>
        <td><span class="badge ${p.is_active ? "badge-ok" : ""}">${p.is_active ? "En ligne" : "Masqué"}</span></td>
        <td class="num" style="white-space:nowrap">
          <button class="btn btn-sm btn-ghost edit" data-id="${p.id}">Modifier</button>
          <button class="btn btn-sm btn-danger del" data-id="${p.id}">Suppr.</button>
        </td></tr>`).join("")}</tbody></table></div>`
      : empty("📦", "Aucun article publié", "Ajoutez votre premier article pour apparaître dans le catalogue général."));

  $("#btnNew").onclick = () => productForm(null);
  $$(".edit").forEach(b => b.onclick = () => productForm(data.find(p => p.id === b.dataset.id)));
  $$(".del").forEach(b => b.onclick = async () => {
    if (!confirm("Supprimer définitivement cet article ?")) return;
    const { error } = await sb.from("products").delete().eq("id", b.dataset.id);
    if (error) return toast(humanError(error), "err");
    toast("Article supprimé", "ok"); route();
  });
}

function productForm(p) {
  openModal(p ? "Modifier l'article" : "Nouvel article", `
    <form id="pf">
      <div class="field"><label>Nom de l'article *</label><input name="name" required value="${esc(p?.name || "")}" placeholder="Carton de 12 bouteilles 75 cl"></div>
      <div class="row">
        <div class="field"><label>Référence / SKU</label><input name="sku" value="${esc(p?.sku || "")}"></div>
        <div class="field"><label>Catégorie</label><input name="category" value="${esc(p?.category || "")}" placeholder="Boissons"></div>
      </div>
      <div class="field"><label>Description</label><textarea name="description" placeholder="Conditionnement, origine, délai de livraison…">${esc(p?.description || "")}</textarea></div>
      <div class="row">
        <div class="field"><label>Prix HT *</label><input name="price_ht" type="number" step="0.01" min="0" required value="${p?.price_ht ?? ""}"></div>
        <div class="field"><label>Unité de vente</label><select name="unit">${UNITS.map(u => `<option ${p?.unit === u ? "selected" : ""}>${u}</option>`).join("")}</select></div>
      </div>
      <div class="row">
        <div class="field"><label>Quantité minimum</label><input name="min_qty" type="number" min="1" step="1" value="${p?.min_qty ?? 1}"></div>
        <div class="field"><label>Stock disponible</label><input name="stock" type="number" min="0" step="1" value="${p?.stock ?? 0}"></div>
      </div>
      <div class="field"><label>URL de l'image (facultatif)</label><input name="image_url" type="url" value="${esc(p?.image_url || "")}" placeholder="https://…"></div>
      <div class="field"><label style="display:flex;gap:.5rem;align-items:center;font-size:.95rem;color:var(--text)">
        <input type="checkbox" name="is_active" style="width:auto" ${p?.is_active !== false ? "checked" : ""}> Visible dans le catalogue général</label></div>
      <div style="display:flex;gap:.6rem;justify-content:flex-end">
        <button type="button" class="btn btn-ghost" id="pfCancel">Annuler</button>
        <button type="submit" class="btn btn-primary">${p ? "Enregistrer" : "Publier"}</button>
      </div>
    </form>`);

  $("#pfCancel").onclick = closeModal;
  $("#pf").onsubmit = async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const payload = {
      company_id: state.company.id,
      name: f.get("name").trim(),
      sku: f.get("sku").trim() || null,
      category: f.get("category").trim() || null,
      description: f.get("description").trim() || null,
      price_ht: Number(f.get("price_ht")),
      unit: f.get("unit"),
      min_qty: Math.max(parseInt(f.get("min_qty"), 10) || 1, 1),
      stock: parseInt(f.get("stock"), 10) || 0,
      image_url: f.get("image_url").trim() || null,
      is_active: f.get("is_active") === "on",
      updated_at: new Date().toISOString(),
    };
    const { error } = p
      ? await sb.from("products").update(payload).eq("id", p.id)
      : await sb.from("products").insert(payload);
    if (error) return toast(humanError(error), "err");
    closeModal(); toast(p ? "Article mis à jour" : "Article publié", "ok"); route();
  };
}

/* =============================================================== PANIER */
async function viewCart() {
  if (!state.cart.length) {
    $("#view").innerHTML = head("Panier", "Vos articles sélectionnés") +
      empty("🛒", "Votre panier est vide", "Parcourez le catalogue général pour ajouter des articles.");
    return;
  }
  const sellers = [...new Map(state.cart.map(i => [i.seller_id, i.seller_name])).entries()];

  $("#view").innerHTML = head("Panier", "Une commande distincte est créée pour chaque fournisseur") +
    sellers.map(([sid, sname]) => {
      const lines = state.cart.filter(i => i.seller_id === sid);
      const total = lines.reduce((s, i) => s + i.price * i.qty, 0);
      return `<div class="card" style="margin-bottom:1.2rem">
        <div class="card-pad" style="padding-bottom:.2rem;display:flex;justify-content:space-between;align-items:center">
          <h3 style="margin:0">🏢 ${esc(sname)}</h3><span class="hint">${lines.length} ligne(s)</span></div>
        <table><thead><tr><th>Article</th><th class="num">P.U. HT</th><th class="num">Quantité</th><th class="num">Total HT</th><th></th></tr></thead>
        <tbody>${lines.map(i => `<tr>
          <td><b>${esc(i.name)}</b><div class="hint">${esc(i.unit)} · min ${i.min_qty}</div></td>
          <td class="num">${money(i.price)}</td>
          <td class="num"><input class="qty cqty" type="number" min="${i.min_qty}" value="${i.qty}" data-id="${i.product_id}"></td>
          <td class="num"><b>${money(i.price * i.qty)}</b></td>
          <td class="num"><button class="btn btn-sm btn-danger rm" data-id="${i.product_id}">×</button></td>
        </tr>`).join("")}</tbody></table>
        <div class="card-pad" style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap">
          <input class="note" data-sid="${sid}" placeholder="Note pour le fournisseur (facultatif)" style="flex:1;min-width:200px">
          <div style="display:flex;align-items:center;gap:1rem">
            <div><span class="hint">Total HT</span> <b style="font-size:1.2rem">${money(total)}</b></div>
            <button class="btn btn-primary order" data-sid="${sid}">Passer commande</button>
          </div>
        </div></div>`;
    }).join("") +
    `<button class="btn btn-ghost" id="clearCart">Vider le panier</button>`;

  $$(".cqty").forEach(inp => inp.onchange = () => {
    const line = state.cart.find(i => i.product_id === inp.dataset.id);
    line.qty = Math.max(parseInt(inp.value, 10) || line.min_qty, line.min_qty);
    saveCart(); route();
  });
  $$(".rm").forEach(b => b.onclick = () => {
    state.cart = state.cart.filter(i => i.product_id !== b.dataset.id); saveCart(); route();
  });
  $("#clearCart").onclick = () => { state.cart = []; saveCart(); route(); };

  $$(".order").forEach(b => b.onclick = async () => {
    const sid = b.dataset.sid;
    b.disabled = true; b.textContent = "Envoi…";
    const items = state.cart.filter(i => i.seller_id === sid)
      .map(i => ({ product_id: i.product_id, quantity: i.qty }));
    const note = $(`.note[data-sid="${sid}"]`)?.value.trim() || null;
    const { error } = await sb.rpc("place_order", { p_seller: sid, p_items: items, p_note: note });
    if (error) { b.disabled = false; b.textContent = "Passer commande"; return toast(humanError(error), "err"); }
    state.cart = state.cart.filter(i => i.seller_id !== sid); saveCart();
    toast("Commande envoyée au fournisseur", "ok");
    location.hash = "#achats";
  });
}

/* ====================================================== COMMANDES */
async function viewPurchases() { await ordersView("achat"); }
async function viewSales()     { await ordersView("vente"); }

async function ordersView(sens) {
  const col = sens === "achat" ? "buyer_company_id" : "seller_company_id";
  const other = sens === "achat" ? "seller_company_id" : "buyer_company_id";

  const { data, error } = await sb.from("orders")
    .select("*, order_items(*)").eq(col, state.company.id)
    .order("created_at", { ascending: false });
  if (error) throw error;
  const names = await companyNames(data.map(o => o[other]));

  const title = sens === "achat" ? "Mes commandes" : "Commandes reçues";
  const sub = sens === "achat"
    ? "Ce que vous avez commandé auprès des autres entreprises"
    : "Ce que les autres entreprises vous ont commandé";

  $("#view").innerHTML = head(title, sub) + (data.length ? data.map(o => `
    <div class="card" style="margin-bottom:1rem">
      <div class="card-pad" style="display:flex;justify-content:space-between;gap:1rem;flex-wrap:wrap;align-items:center">
        <div>
          <b>${esc(o.reference)}</b>
          <span class="badge ${STATUS[o.status]?.cls || ""}" style="margin-left:.5rem">${STATUS[o.status]?.label || o.status}</span>
          <div class="hint">${sens === "achat" ? "Fournisseur" : "Client"} : <b>${esc(names[o[other]] || "—")}</b> · ${dateFR(o.created_at)}</div>
          ${o.note ? `<div class="hint">📝 ${esc(o.note)}</div>` : ""}
        </div>
        <div style="text-align:right">
          <div class="hint">Total HT</div><b style="font-size:1.25rem">${money(o.total_ht)}</b>
        </div>
      </div>
      <table><thead><tr><th>Article</th><th class="num">P.U. HT</th><th class="num">Qté</th><th class="num">Total</th></tr></thead>
      <tbody>${(o.order_items || []).map(i => `<tr>
        <td>${esc(i.product_name)}</td><td class="num">${money(i.unit_price_ht)}</td>
        <td class="num">${i.quantity} ${esc(i.unit || "")}</td><td class="num">${money(i.line_total)}</td></tr>`).join("")}
      </tbody></table>
      <div class="card-pad" style="display:flex;gap:.5rem;justify-content:flex-end;flex-wrap:wrap">${statusButtons(o, sens)}</div>
    </div>`).join("")
    : empty(sens === "achat" ? "📥" : "📤",
            sens === "achat" ? "Aucune commande passée" : "Aucune commande reçue",
            sens === "achat" ? "Ajoutez des articles au panier depuis le catalogue général."
                             : "Publiez vos articles pour être visible des autres entreprises."));

  $$(".setstatus").forEach(b => b.onclick = async () => {
    const { error } = await sb.from("orders")
      .update({ status: b.dataset.status, updated_at: new Date().toISOString() })
      .eq("id", b.dataset.id);
    if (error) return toast(humanError(error), "err");
    toast("Statut mis à jour", "ok"); route();
  });
}

function statusButtons(o, sens) {
  const B = (s, label, cls = "btn-ghost") =>
    `<button class="btn btn-sm ${cls} setstatus" data-id="${o.id}" data-status="${s}">${label}</button>`;
  if (o.status === "annulee" || o.status === "livree") return `<span class="hint">Commande clôturée</span>`;
  if (sens === "vente") {
    return [
      o.status === "en_attente" ? B("confirmee", "Confirmer", "btn-primary") : "",
      o.status === "confirmee"  ? B("expediee", "Marquer expédiée", "btn-primary") : "",
      o.status === "expediee"   ? B("livree", "Marquer livrée", "btn-primary") : "",
      B("annulee", "Refuser", "btn-danger"),
    ].join("");
  }
  return o.status === "en_attente" ? B("annulee", "Annuler ma commande", "btn-danger")
                                   : `<span class="hint">En cours de traitement par le fournisseur</span>`;
}

/* ============================================================== ÉQUIPE */
async function viewTeam() {
  const cid = state.company.id;
  const max = state.company.max_members ?? 5;

  const [{ data: members, error }, { data: access }] = await Promise.all([
    sb.from("profiles").select("id,full_name,discord_username,avatar_url,role,email,created_at")
      .eq("company_id", cid).order("created_at"),
    sb.from("company_access").select("join_code").eq("company_id", cid).maybeSingle(),
  ]);
  if (error) throw error;

  const n = members.length;
  const seats = Array.from({ length: max }, (_, i) =>
    `<span class="seat ${i < n ? "on" : ""}"></span>`).join("");

  $("#view").innerHTML =
    head("Mon équipe", `${n} membre(s) sur ${max} places · seuls les membres de votre entreprise voient cet écran`) + `
    ${isAdmin() ? `<div class="card card-pad" style="margin-bottom:1.2rem">
      <h3>Code d'invitation</h3>
      <p class="hint">Transmettez-le aux personnes de votre entreprise. Elles le saisiront après s'être connectées avec Discord.</p>
      <div class="code-box">
        <b id="codeVal">${esc(access?.join_code || "—")}</b>
        <div style="display:flex;gap:.5rem">
          <button class="btn btn-sm btn-ghost" id="copyCode">Copier</button>
          <button class="btn btn-sm btn-ghost" id="regen">Régénérer</button>
        </div>
      </div>
      <p class="hint" style="margin:.7rem 0 0">Régénérer invalide l'ancien code : les membres déjà rattachés ne sont pas affectés.</p>
    </div>` : ""}

    <div class="card">
      <div class="card-pad" style="display:flex;justify-content:space-between;align-items:center;gap:1rem;flex-wrap:wrap">
        <h3 style="margin:0">Membres</h3>
        <div class="seats" title="${n} / ${max}">${seats}<span class="hint" style="margin-left:.5rem">${n} / ${max}</span></div>
      </div>
      <table><thead><tr><th>Membre</th><th>Discord</th><th>Rôle</th><th>Depuis</th>${isAdmin() ? "<th></th>" : ""}</tr></thead>
      <tbody>${members.map(m => `<tr>
        <td><div class="member">
          ${m.avatar_url ? `<img class="avatar" src="${esc(m.avatar_url)}" alt="">` : `<span class="avatar"></span>`}
          <div class="meta"><b>${esc(displayName(m))}</b>
            <span class="hint">${m.id === state.user.id ? "vous" : esc(m.email || "")}</span></div></div></td>
        <td class="hint">${esc(m.discord_username || "—")}</td>
        <td><span class="badge ${m.role === "admin" ? "badge-info" : ""}">${m.role === "admin" ? "Administrateur" : "Membre"}</span></td>
        <td class="hint">${dateFR(m.created_at)}</td>
        ${isAdmin() ? `<td class="num" style="white-space:nowrap">
          ${m.id === state.user.id ? "" : `
            <button class="btn btn-sm btn-ghost role" data-id="${m.id}" data-role="${m.role === "admin" ? "membre" : "admin"}">
              ${m.role === "admin" ? "Rétrograder" : "Promouvoir"}</button>
            <button class="btn btn-sm btn-danger kick" data-id="${m.id}" data-name="${esc(displayName(m))}">Retirer</button>`}
        </td>` : ""}
      </tr>`).join("")}</tbody></table>
      ${n >= max ? `<div class="card-pad"><p class="hint">⚠️ Toutes les places sont occupées. Retirez un membre pour en inviter un autre.</p></div>` : ""}
    </div>`;

  if (isAdmin()) {
    $("#copyCode").onclick = async () => {
      try { await navigator.clipboard.writeText($("#codeVal").textContent); toast("Code copié", "ok"); }
      catch { toast("Copie impossible — sélectionnez le code à la main", "err"); }
    };
    $("#regen").onclick = async () => {
      if (!confirm("Générer un nouveau code ? L'ancien ne fonctionnera plus.")) return;
      const { data, error } = await sb.rpc("regenerate_join_code");
      if (error) return toast(humanError(error), "err");
      $("#codeVal").textContent = data; toast("Nouveau code généré", "ok");
    };
    $$(".role").forEach(b => b.onclick = async () => {
      const { error } = await sb.rpc("set_member_role", { p_user: b.dataset.id, p_role: b.dataset.role });
      if (error) return toast(humanError(error), "err");
      toast("Rôle mis à jour", "ok"); route();
    });
    $$(".kick").forEach(b => b.onclick = async () => {
      if (!confirm(`Retirer ${b.dataset.name} de l'entreprise ?`)) return;
      const { error } = await sb.rpc("remove_member", { p_user: b.dataset.id });
      if (error) return toast(humanError(error), "err");
      toast("Membre retiré", "ok"); route();
    });
  }
}

/* ==================================================== CONSOLE STAFF === */
let staffData = null;

async function viewStaff() {
  if (!state.profile.is_staff) {
    $("#view").innerHTML = empty("🚫", "Accès réservé", "Cette console est réservée à l'équipe qui administre la plateforme.");
    return;
  }
  const { data, error } = await sb.rpc("staff_overview");
  if (error) throw error;
  staffData = data;
  const s = data.stats;

  $("#view").innerHTML =
    head("Console staff", "Vue et gestion de toutes les entreprises de la plateforme",
         `<button class="btn btn-primary" id="newCo">+ Nouvelle entreprise</button>`) + `
    <div class="grid stats">
      <div class="stat"><div class="label">Entreprises</div><div class="value">${s.entreprises}</div>
        <div class="sub">${s.actives} active(s)</div></div>
      <div class="stat"><div class="label">Membres</div><div class="value">${s.membres}</div>
        <div class="sub">staff non compté</div></div>
      <div class="stat"><div class="label">Articles</div><div class="value">${s.articles}</div>
        <div class="sub">tous catalogues</div></div>
      <div class="stat"><div class="label">Commandes</div><div class="value">${s.commandes}</div>
        <div class="sub">depuis le lancement</div></div>
      <div class="stat"><div class="label">Volume HT</div><div class="value">${money(s.ca_ht)}</div>
        <div class="sub">hors annulations</div></div>
    </div>

    <div class="toolbar"><input id="sSearch" type="search" placeholder="Rechercher une entreprise, une ville, un code…"></div>
    <div class="card" style="margin-bottom:1.4rem"><div id="coTable"></div></div>

    <div class="grid" style="grid-template-columns:repeat(auto-fit,minmax(340px,1fr))">
      <div class="card">
        <div class="card-pad" style="padding-bottom:.3rem"><h3>Comptes sans entreprise</h3>
          <p class="hint" style="margin:0">Connectés avec Discord mais pas encore rattachés.</p></div>
        ${data.sans_entreprise.length ? `<table><thead><tr><th>Personne</th><th>Rattacher à</th><th></th></tr></thead><tbody>
          ${data.sans_entreprise.map(u => `<tr>
            <td><b>${esc(u.name || "—")}</b>${u.is_staff ? ` <span class="badge badge-info">staff</span>` : ""}
                <div class="hint">${esc(u.discord || "")}</div></td>
            <td><select class="assign" data-id="${u.id}">
              <option value="">— choisir —</option>
              ${data.companies.map(c => `<option value="${c.id}">${esc(c.name)} (${c.nb_membres}/${c.max_members})</option>`).join("")}
            </select></td>
            <td class="num"><button class="btn btn-sm btn-ghost tstaff" data-id="${u.id}" data-val="${!u.is_staff}">
              ${u.is_staff ? "Retirer staff" : "Nommer staff"}</button></td>
          </tr>`).join("")}
        </tbody></table>` : `<div class="card-pad"><p class="hint">Personne en attente.</p></div>`}
      </div>

      <div class="card">
        <div class="card-pad" style="padding-bottom:.3rem"><h3>Dernières commandes</h3></div>
        ${data.commandes.length ? `<table><thead><tr><th>Réf.</th><th>Vendeur ← Acheteur</th><th>Statut</th><th class="num">HT</th></tr></thead><tbody>
          ${data.commandes.slice(0, 12).map(o => `<tr>
            <td><b>${esc(o.reference)}</b><div class="hint">${dateFR(o.created_at)}</div></td>
            <td>${esc(o.vendeur || "—")} <span class="hint">←</span> ${esc(o.acheteur || "—")}</td>
            <td><span class="badge ${STATUS[o.statut]?.cls || ""}">${STATUS[o.statut]?.label || o.statut}</span></td>
            <td class="num">${money(o.total_ht)}</td></tr>`).join("")}
        </tbody></table>` : `<div class="card-pad"><p class="hint">Aucune commande.</p></div>`}
      </div>
    </div>`;

  const renderCompanies = () => {
    const q = ($("#sSearch").value || "").trim().toLowerCase();
    const list = staffData.companies.filter(c =>
      !q || [c.name, c.city, c.sector, c.join_code].join(" ").toLowerCase().includes(q));

    $("#coTable").innerHTML = list.length ? `<table>
      <thead><tr><th>Entreprise</th><th>Code</th><th class="num">Membres</th><th class="num">Articles</th>
      <th class="num">Ventes</th><th class="num">CA HT</th><th>État</th><th></th></tr></thead>
      <tbody>${list.map(c => `<tr>
        <td><b>${esc(c.name)}</b><div class="hint">${esc([c.city, c.sector].filter(Boolean).join(" · ") || "—")}</div></td>
        <td><code class="hint" style="font-size:.95rem;letter-spacing:.08em">${esc(c.join_code || "—")}</code>
            <button class="btn btn-sm btn-ghost cpy" data-code="${esc(c.join_code || "")}" title="Copier">⧉</button></td>
        <td class="num">${c.nb_membres} / ${c.max_members}</td>
        <td class="num">${c.nb_articles}</td>
        <td class="num">${c.nb_ventes}</td>
        <td class="num">${money(c.ca_ht)}</td>
        <td><span class="badge ${c.is_active ? "badge-ok" : "badge-danger"}">${c.is_active ? "Active" : "Inactive"}</span></td>
        <td class="num" style="white-space:nowrap">
          <button class="btn btn-sm btn-ghost det"  data-id="${c.id}">Détails</button>
          <button class="btn btn-sm btn-ghost edt"  data-id="${c.id}">Modifier</button>
          <button class="btn btn-sm btn-ghost tgl"  data-id="${c.id}" data-val="${!c.is_active}">${c.is_active ? "Désactiver" : "Activer"}</button>
        </td></tr>`).join("")}</tbody></table>`
      : `<div class="card-pad"><p class="hint">Aucune entreprise ne correspond.</p></div>`;

    $$("#coTable .cpy").forEach(b => b.onclick = async () => {
      try { await navigator.clipboard.writeText(b.dataset.code); toast("Code copié", "ok"); } catch { toast("Copie impossible", "err"); }
    });
    $$("#coTable .edt").forEach(b => b.onclick = () => companyForm(staffData.companies.find(c => c.id === b.dataset.id)));
    $$("#coTable .det").forEach(b => b.onclick = () => companyDetail(staffData.companies.find(c => c.id === b.dataset.id)));
    $$("#coTable .tgl").forEach(b => b.onclick = async () => {
      const { error } = await sb.rpc("staff_set_active", { p_company: b.dataset.id, p_active: b.dataset.val === "true" });
      if (error) return toast(humanError(error), "err");
      toast("État mis à jour", "ok"); route();
    });
  };

  $("#sSearch").oninput = renderCompanies;
  renderCompanies();

  $("#newCo").onclick = () => companyForm(null);
  $$(".assign").forEach(sel => sel.onchange = async () => {
    if (!sel.value) return;
    const { error } = await sb.rpc("staff_assign_member",
      { p_user: sel.dataset.id, p_company: sel.value, p_role: "membre" });
    if (error) { sel.value = ""; return toast(humanError(error), "err"); }
    toast("Membre rattaché", "ok"); route();
  });
  $$(".tstaff").forEach(b => b.onclick = async () => {
    const { error } = await sb.rpc("staff_set_staff", { p_user: b.dataset.id, p_valeur: b.dataset.val === "true" });
    if (error) return toast(humanError(error), "err");
    toast("Droits mis à jour", "ok"); route();
  });
}

function companyForm(c) {
  openModal(c ? `Modifier — ${c.name}` : "Nouvelle entreprise", `
    <form id="scf">
      <div class="field"><label>Nom de l'entreprise *</label><input name="name" required value="${esc(c?.name || "")}" placeholder="Distribution Martin"></div>
      <div class="row">
        <div class="field"><label>Ville</label><input name="city" value="${esc(c?.city || "")}"></div>
        <div class="field"><label>Secteur</label><input name="sector" value="${esc(c?.sector || "")}"></div>
      </div>
      <div class="row">
        <div class="field"><label>SIRET</label><input name="siret" value="${esc(c?.siret || "")}"></div>
        <div class="field"><label>Téléphone</label><input name="phone" value="${esc(c?.phone || "")}"></div>
      </div>
      <div class="row">
        <div class="field"><label>Pays</label><input name="country" value="${esc(c?.country || "France")}"></div>
        <div class="field"><label>Places (membres max)</label><input name="max_members" type="number" min="1" max="50" value="${c?.max_members ?? 5}"></div>
      </div>
      <div class="field"><label>Présentation</label><textarea name="description">${esc(c?.description || "")}</textarea></div>
      <div class="row">
        <div class="field"><label>ID serveur Discord</label><input name="discord_guild_id" value="${esc(c?.discord_guild_id || "")}"></div>
        <div class="field"><label>ID salon Discord</label><input name="discord_channel_id" value="${esc(c?.discord_channel_id || "")}"></div>
      </div>
      ${c ? `<div class="code-box" style="margin-bottom:1rem">
        <b>${esc(c.join_code || "—")}</b>
        <button type="button" class="btn btn-sm btn-ghost" id="scRegen">Régénérer le code</button></div>` : ""}
      <div style="display:flex;gap:.6rem;justify-content:space-between;flex-wrap:wrap">
        ${c ? `<button type="button" class="btn btn-danger btn-sm" id="scDel">Supprimer</button>` : "<span></span>"}
        <span style="display:flex;gap:.6rem">
          <button type="button" class="btn btn-ghost" id="scCancel">Annuler</button>
          <button type="submit" class="btn btn-primary">${c ? "Enregistrer" : "Créer l'entreprise"}</button>
        </span>
      </div>
    </form>`);

  $("#scCancel").onclick = closeModal;

  if (c) {
    $("#scRegen").onclick = async () => {
      if (!confirm("Générer un nouveau code ? L'ancien ne fonctionnera plus.")) return;
      const { data, error } = await sb.rpc("staff_regenerate_code", { p_company: c.id });
      if (error) return toast(humanError(error), "err");
      toast(`Nouveau code : ${data}`, "ok"); closeModal(); route();
    };
    $("#scDel").onclick = async () => {
      if (!confirm(`Supprimer définitivement « ${c.name} » ?`)) return;
      const { error } = await sb.rpc("staff_delete_company", { p_company: c.id });
      if (error) return toast(humanError(error), "err");
      toast("Entreprise supprimée", "ok"); closeModal(); route();
    };
  }

  $("#scf").onsubmit = async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const p = {};
    for (const [k, v] of f.entries()) p[k] = String(v).trim();
    p.max_members = parseInt(p.max_members, 10) || 5;
    const { data, error } = await sb.rpc("staff_save_company", { p_id: c?.id ?? null, p });
    if (error) return toast(humanError(error), "err");
    closeModal();
    toast(c ? "Entreprise mise à jour" : `Entreprise créée — code ${data.join_code}`, "ok");
    route();
  };
}

async function companyDetail(c) {
  openModal(c.name, `<p class="hint">Chargement…</p>`);
  const { data, error } = await sb.rpc("staff_company_detail", { p_company: c.id });
  if (error) { $("#modalContent").innerHTML = `<p>${esc(humanError(error))}</p>`; return; }

  $("#modalContent").innerHTML = `
    <div class="code-box" style="margin-bottom:1.1rem">
      <div><span class="hint">Code d'invitation</span><br><b>${esc(c.join_code || "—")}</b></div>
      <div class="hint">${c.nb_membres} / ${c.max_members} places · ${c.is_active ? "active" : "inactive"}</div>
    </div>

    <h3>Membres</h3>
    ${c.members.length ? `<table><tbody>${c.members.map(m => `<tr>
      <td><b>${esc(m.name || "—")}</b>${m.is_staff ? ` <span class="badge badge-info">staff</span>` : ""}
          <div class="hint">${esc(m.discord || "")}</div></td>
      <td><span class="badge ${m.role === "admin" ? "badge-info" : ""}">${m.role === "admin" ? "Admin" : "Membre"}</span></td>
      <td class="num"><button class="btn btn-sm btn-danger det-kick" data-id="${m.id}">Détacher</button></td>
    </tr>`).join("")}</tbody></table>` : `<p class="hint">Aucun membre rattaché.</p>`}

    <h3 style="margin-top:1.4rem">Articles (${data.articles.length})</h3>
    ${data.articles.length ? `<table><thead><tr><th>Article</th><th class="num">Prix HT</th><th class="num">Stock</th><th>État</th></tr></thead>
      <tbody>${data.articles.map(a => `<tr>
        <td>${esc(a.name)}<div class="hint">${esc(a.category || "—")}</div></td>
        <td class="num">${money(a.price_ht)}<div class="hint">/ ${esc(a.unit)}</div></td>
        <td class="num">${a.stock}</td>
        <td><span class="badge ${a.is_active ? "badge-ok" : ""}">${a.is_active ? "En ligne" : "Masqué"}</span></td>
      </tr>`).join("")}</tbody></table>` : `<p class="hint">Aucun article publié.</p>`}

    <h3 style="margin-top:1.4rem">Commandes (${data.commandes.length})</h3>
    ${data.commandes.length ? `<table><thead><tr><th>Réf.</th><th>Sens</th><th>Contrepartie</th><th>Statut</th><th class="num">HT</th></tr></thead>
      <tbody>${data.commandes.slice(0, 20).map(o => `<tr>
        <td><b>${esc(o.reference)}</b><div class="hint">${dateFR(o.created_at)}</div></td>
        <td>${o.sens === "vente" ? "📤 Vente" : "📥 Achat"}</td>
        <td>${esc(o.contrepartie || "—")}</td>
        <td><span class="badge ${STATUS[o.statut]?.cls || ""}">${STATUS[o.statut]?.label || o.statut}</span></td>
        <td class="num">${money(o.total_ht)}</td>
      </tr>`).join("")}</tbody></table>` : `<p class="hint">Aucune commande.</p>`}`;

  $$(".det-kick").forEach(b => b.onclick = async () => {
    if (!confirm("Détacher ce membre de l'entreprise ?")) return;
    const { error } = await sb.rpc("staff_assign_member", { p_user: b.dataset.id, p_company: null, p_role: "membre" });
    if (error) return toast(humanError(error), "err");
    toast("Membre détaché", "ok"); closeModal(); route();
  });
}

/* ========================================================== ENTREPRISE */
async function viewCompany() {
  const c = state.company;
  const admin = isAdmin();
  const { data: settings } = await sb.from("company_settings")
    .select("*").eq("company_id", c.id).maybeSingle();
  const dis = admin ? "" : "disabled";

  $("#view").innerHTML = head("Mon entreprise",
      admin ? "Ces informations sont visibles par les autres membres"
            : "Consultation seule — seul un administrateur peut modifier ces informations") + `
    <div class="card card-pad" style="max-width:640px;margin-bottom:1.2rem">
      <form id="cf">
        <div class="field"><label>Nom de l'entreprise *</label><input name="name" required ${dis} value="${esc(c.name || "")}"></div>
        <div class="row">
          <div class="field"><label>SIRET</label><input name="siret" ${dis} value="${esc(c.siret || "")}"></div>
          <div class="field"><label>Secteur d'activité</label><input name="sector" ${dis} value="${esc(c.sector || "")}"></div>
        </div>
        <div class="row">
          <div class="field"><label>Ville</label><input name="city" ${dis} value="${esc(c.city || "")}"></div>
          <div class="field"><label>Pays</label><input name="country" ${dis} value="${esc(c.country || "France")}"></div>
        </div>
        <div class="field"><label>Téléphone</label><input name="phone" ${dis} value="${esc(c.phone || "")}"></div>
        <div class="field"><label>Présentation</label><textarea name="description" ${dis} placeholder="Votre activité, vos gammes, vos zones de livraison…">${esc(c.description || "")}</textarea></div>
        ${admin ? `<button class="btn btn-primary" type="submit">Enregistrer</button>` : ""}
      </form>
    </div>

    <div class="card card-pad" style="max-width:640px">
      <h3>Notifications Discord</h3>
      <p class="hint">Où le bot annoncera les commandes reçues par votre entreprise. À remplir quand le bot sera en place — vous pouvez laisser vide pour l'instant.</p>
      <form id="df" style="margin-top:1rem">
        <div class="row">
          <div class="field"><label>ID du serveur Discord</label><input name="discord_guild_id" ${dis} value="${esc(settings?.discord_guild_id || "")}" placeholder="123456789012345678"></div>
          <div class="field"><label>ID du salon</label><input name="discord_channel_id" ${dis} value="${esc(settings?.discord_channel_id || "")}" placeholder="123456789012345678"></div>
        </div>
        <div class="field"><label>URL de webhook (alternative au bot)</label>
          <input name="discord_webhook_url" type="url" ${dis} value="${esc(settings?.discord_webhook_url || "")}" placeholder="https://discord.com/api/webhooks/…"></div>
        ${admin ? `<button class="btn btn-primary" type="submit">Enregistrer</button>` : ""}
      </form>
    </div>`;

  if (!admin) return;

  $("#cf").onsubmit = async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const payload = Object.fromEntries([...f.entries()].map(([k, v]) => [k, String(v).trim() || null]));
    const { data, error } = await sb.from("companies").update(payload).eq("id", c.id).select().single();
    if (error) return toast(humanError(error), "err");
    state.company = { ...state.company, ...data };
    $("#whoCompany").textContent = data.name;
    toast("Fiche entreprise enregistrée", "ok");
  };

  $("#df").onsubmit = async (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const payload = { company_id: c.id, updated_at: new Date().toISOString() };
    for (const [k, v] of f.entries()) payload[k] = String(v).trim() || null;
    const { error } = await sb.from("company_settings").upsert(payload, { onConflict: "company_id" });
    if (error) return toast(humanError(error), "err");
    toast("Réglages Discord enregistrés", "ok");
  };
}
