/* Page publique : connexion via Discord */
import { sb, configOK, $, toast, humanError, showSetupScreen } from "./common.js";

if (!configOK) showSetupScreen();
else init();

function init() {
  const C = window.CONFIG;
  $("#brandName").textContent = C.APP_NAME || "Grosso";
  document.title = `${C.APP_NAME || "Grosso"} — ${C.APP_TAGLINE || "Place de marché B2B"}`;

  const msg = $("#authMsg");
  const btn = $("#btnDiscord");

  // Adresse de retour après authentification Discord
  const appUrl = new URL("app.html", location.href).href;

  // Déjà connecté ? on file vers l'application
  sb.auth.getSession().then(({ data }) => {
    if (data.session) location.replace("app.html");
  });

  // Discord renvoie parfois une erreur dans l'URL
  const params = new URLSearchParams(location.hash.replace("#", "") || location.search);
  if (params.get("error_description")) {
    msg.textContent = decodeURIComponent(params.get("error_description"));
    toast(msg.textContent, "err");
  }

  btn.addEventListener("click", async () => {
    btn.disabled = true;
    const label = btn.innerHTML;
    btn.textContent = "Redirection vers Discord…";
    const { error } = await sb.auth.signInWithOAuth({
      provider: "discord",
      options: { redirectTo: appUrl, scopes: "identify email" },
    });
    if (error) {
      btn.disabled = false;
      btn.innerHTML = label;
      msg.textContent = humanError(error);
      toast(humanError(error), "err");
    }
  });
}
